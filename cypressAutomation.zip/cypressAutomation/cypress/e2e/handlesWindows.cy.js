describe("Browser Windows Test", () => {
    it("should handle new tabs and windows", () => {
      // Step 1: Visit the website
      cy.visit("https://demoqa.com/browser-windows")
  
      // Step 2: Wait for 5 seconds
      cy.wait(5000)
  
      // Step 3: Click on 'New Tab' button
      cy.get("#tabButton").click()
  
      // Step 4: Switch back to the previous tab
      cy.window().then((win) => {
        win.history.back()
      });
  
      // Step 5: Click on 'New Window' button
      cy.get("#windowButton").click()
  
      // Step 6: Switch back to the previous window
      cy.window().then((win) => {
        win.history.back()
      });
  
      // Step 7: Click on 'New Window Message' button
      cy.get("#messageWindowButton").click()
  

    })
  })
  